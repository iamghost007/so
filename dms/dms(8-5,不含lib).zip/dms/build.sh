#!/bin/bash
SPRINGSIDE_HOME=../../		

if test -z $JAVA_HOME; then
    echo '请先设置JAVA_HOME环境变量'
else
    "$JAVA_HOME/bin/java" -cp $SPRINGSIDE_HOME/tools/ant/lib/ant.jar:$SPRINGSIDE_HOME/tools/ant/lib/ant-nodeps.jar:$SPRINGSIDE_HOME/tools/ant/lib/ant-junit.jar:$SPRINGSIDE_HOME/tools/test/lib/junit-3.8.1.jar:$JAVA_HOME/lib/tools.jar org.apache.tools.ant.Main -f build.xml $1
fi