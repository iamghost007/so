package net.bobstudio.dms.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.bobstudio.dms.model.Devicedata;
import net.bobstudio.dms.model.Device;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.criterion.Restrictions;
import org.springside.core.commons.HibernateEntityDao;
import org.springside.core.commons.HibernateGenericDao;
import org.springside.core.commons.support.Page;

/**
 * 设备数据管理类.
 * <p/>
 * 
 * @author Bob
 * @see HibernateEntityDao
 * @see HibernateGenericDao
 * @see DevicedataManagerFullVersion
 */
public class DevicedataManager extends HibernateEntityDao<Devicedata> {
	private int pageSize;
	private int permittedMaxRecords;
	private int intervalTime;

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public int getPermittedMaxRecords() {
		return permittedMaxRecords;
	}

	public void setPermittedMaxRecords(int permittedMaxRecords) {
		this.permittedMaxRecords = permittedMaxRecords;
	}

	public int getIntervalTime() {
		return intervalTime;
	}

	public void setIntervalTime(int intervalTime) {
		this.intervalTime = intervalTime;
	}

	/**
	 * 分页获取最新设备数据
	 */
	public Page getNewDevicedatas(Integer pageNo, Integer pageSize,
			Integer deviceId) {
		if (pageSize > 1) {
			limitMaxRecordsHook();
		}
		return this.pagedQuery(
				"from Devicedata where device.id=? order by id desc", pageNo,
				pageSize, deviceId);
	}

	public Devicedata getLastOneByDeviceId(Integer deviceId) {
		List<Devicedata> lst = (List<Devicedata>) getNewDevicedatas(0, 1,
				deviceId).getResult();
		
		if(lst.size() >0 ) {
			return lst.get(0);
		}
		else {
			Devicedata data = new Devicedata();
			data.setDevice(getDevice(deviceId));
			return data;
		}
		
		//return lst.size() > 0 ? lst.get(0) : new Devicedata();
	}

	/**
	 * 按Map中包含的条件组装criteria 进行查询。 Map中仅包含条件名与条件值，运算符由业务方法自行决定。
	 */
	public List find(Map map) {
		Criteria criteria = getEntityCriteria();
		String device = (String) map.get("device");
		if (StringUtils.isNotBlank(device)) {
			criteria.createAlias("device", "c").add(
					Restrictions.eq("c.id", new Integer(device)));
		}
		return criteria.list();
	}

	/**
	 * 按设备列出明细
	 */
	public List findDevicedatasByDevice(String deviceId) {
		Map<String, String> filter = new HashMap<String, String>();
		filter.put("device", deviceId);
		return find(filter);
	}

	@Override
	public void save(Object data) {
		super.save(data);

		limitMaxRecordsHook();
	}

	private void limitMaxRecordsHook() {
		// String countQueryString = " select count (*) from Devicedata";
		// List countlist = getHibernateTemplate().find(countQueryString);
		// int todoDeletedNum = (Integer) countlist.get(0) -
		// getPermittedMaxRecords();
		//
		// if(todoDeletedNum > 0) {
		// String deletedQueryString = "from Devicedata ";
		// }
		//
		Query query = getSession().createQuery(
				"select id from Devicedata order by id desc");
		List list = query.setFirstResult(getPermittedMaxRecords())
				.setMaxResults(1).list();
		if (list != null && list.size() > 0) {
			Integer id = (Integer) list.get(0);
			getHibernateTemplate().bulkUpdate(
					"delete from Devicedata where id < ?", id);
		}

	}

	/**
	 * 获取全部设备
	 */
	public List<Device> getDevices() {
		return getAll(Device.class);
	}

	/**
	 * 按id获得设备
	 */
	public Device getDevice(Integer id) {
		return get(Device.class, id);
	}

}
