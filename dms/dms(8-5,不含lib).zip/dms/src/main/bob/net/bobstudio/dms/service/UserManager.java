package net.bobstudio.dms.service;

import java.io.Serializable;

import org.springframework.orm.ObjectRetrievalFailureException;
import org.springside.bookstore.components.acegi.domain.Role;
import org.springside.bookstore.components.acegi.domain.User;
import org.springside.core.commons.HibernateEntityDao;
import org.springside.core.commons.HibernateGenericDao;

/**
 * 用户管理业务类.
 * <p/>
 *
 * @author Bob
 * @see  HibernateEntityDao
 * @see HibernateGenericDao
 * @see UserManagerFullVersion
 */
public class UserManager extends HibernateEntityDao<User> {
	
    public User getUsernameAndPwdById(Serializable id) {
        User user = (User) getHibernateTemplate().get(User.class, id);
        if (user == null) {
            throw new ObjectRetrievalFailureException(User.class, id);
        }
        return user;
    }
    
    public Role getRoleById(Serializable id) {
    	Role role =(Role)getHibernateTemplate().get(Role.class, id);
    	if(role == null) {
    		throw new ObjectRetrievalFailureException(Role.class, id);
    	}
    	
    	return role;
    }
}
