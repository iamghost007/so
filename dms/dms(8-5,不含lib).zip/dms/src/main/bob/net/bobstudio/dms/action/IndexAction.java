package net.bobstudio.dms.action;

import static org.acegisecurity.ui.webapp.AuthenticationProcessingFilter.ACEGI_SECURITY_LAST_USERNAME_KEY;
import net.bobstudio.dms.service.UserManager;

import org.apache.commons.lang.StringUtils;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;
import org.springside.bookstore.components.acegi.domain.User;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * 
 * @author Bob
 */
public class IndexAction extends DispatchAction {
	private UserManager userManager;

	public void setUserManager(UserManager userManager) {
		this.userManager = userManager;
		System.out.println("IndexAction::this is init userManager:" + userManager);
	}

	public ActionForward logout(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) {
		HttpSession session = request.getSession(false);
		if (session != null) {
			session.invalidate();
		}
		return mapping.findForward("logout");
	}

	public ActionForward index(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) {
		HttpSession session = request.getSession(true);
		if (null == session.getAttribute("user")) {
			String loginid = (String) request.getSession(true).getAttribute(ACEGI_SECURITY_LAST_USERNAME_KEY);
			User user;
			if (StringUtils.isNotBlank(loginid)) {
				user = userManager.findUniqueBy("loginid", loginid);
				if (user == null) {
					return mapping.findForward("failed");
				}
				session.setAttribute("user", user);
			}
		}
		return mapping.findForward("success");
	}

	@Override
	public ActionForward unspecified(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) {
		return index(mapping, form, request, response);
	}
}
