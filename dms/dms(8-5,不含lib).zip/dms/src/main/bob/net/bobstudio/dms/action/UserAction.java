package net.bobstudio.dms.action;

import static org.acegisecurity.ui.webapp.AuthenticationProcessingFilter.ACEGI_SECURITY_LAST_USERNAME_KEY;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.bobstudio.dms.service.UserManager;
import net.bobstudio.utils.ErrorsEntityAction;
import net.bobstudio.utils.Md5Utils;

import org.apache.commons.lang.StringUtils;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.springside.bookstore.components.acegi.domain.User;
import org.springside.core.commons.StrutsEntityAction;
import org.springside.core.commons.StrutsAction;

/**
 * 用户管理Controller.
 * 
 * 
 * @author Bob
 * @see StrutsEntityAction
 * @see StrutsAction
 * @see UserActionFullVersion
 */
public class UserAction extends ErrorsEntityAction<User> {
	private UserManager userManager;

	public void setUserManager(UserManager userManager) {
		this.userManager = userManager;
	}

	@Override
	protected UserManager getManager() {
		return userManager;
	}

	@Override
	public ActionForward list(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) {
		String loginid =(String)request.getSession().getAttribute(ACEGI_SECURITY_LAST_USERNAME_KEY);
		if ("admin".equals(loginid)) {
			return super.list(mapping, form, request, response);
		}

		request.setAttribute(getEntityListName(), getManager().findBy("loginid", loginid));
		return mapping.findForward(LIST);
	}

	@Override
	public ActionForward save(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) {
		if (isCancelled(request))
			return list(mapping, form, request, response);

		String loginid = request.getParameter("loginid");
		if (StringUtils.isBlank(request.getParameter("id"))) {// is not edit
			if (StringUtils.isNotBlank(loginid)) {
				if (userManager.findBy("loginid", loginid).size() > 0) { // repeat
																			// loginid
					saveError(request, "errors.loginid");
					return mapping.findForward(EDIT);

				}
			}
		}

		return super.save(mapping, form, request, response);
	}

	@Override
	protected void onInitEntity(ActionForm form, HttpServletRequest request, User user) {
		super.onInitEntity(form, request, user);
		if (user.getId() == null) {
			user.setPasswd(Md5Utils.MD5(user.getPasswd()));
			user.getRoles().add(userManager.getRoleById(2));
		}
	}

}
