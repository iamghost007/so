package net.bobstudio.utils;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.validator.Field;
import org.apache.commons.validator.GenericValidator;
import org.apache.commons.validator.Validator;
import org.apache.commons.validator.ValidatorAction;
import org.apache.commons.validator.util.ValidatorUtils;
import org.apache.struts.action.ActionMessages;
import org.apache.struts.validator.Resources;

/**
 * 
 * 
 * 
 * @author Bob
 */
public class SimpleValidator {
	/**
	 * Checks if the field isn't null and the field is equals passwd2
	 * 
	 * @param bean
	 *            The bean validation is being performed on.
	 * @param va
	 *            The <code>ValidatorAction</code> that is currently being
	 *            performed.
	 * @param field
	 *            The <code>Field</code> object associated with the current
	 *            field being validated.
	 * @param errors
	 *            The <code>ActionMessages</code> object to add errors to if any
	 *            validation errors occur.
	 * @param validator
	 *            The <code>Validator</code> instance, used to access other
	 *            field values.
	 * @param request
	 *            Current request object.
	 * @return true if meets stated requirements, false otherwise.
	 */
	public static boolean validateTwoFields(Object bean, ValidatorAction va,
			Field field, ActionMessages errors, Validator validator,
			HttpServletRequest request) {

		String value = null;
		if (isString(bean)) {
			value = (String) bean;
		} else {
			value = ValidatorUtils.getValueAsString(bean, field.getProperty());
		}

		String value2 = ValidatorUtils.getValueAsString(bean, field.getVarValue("secondField"));

		if(!GenericValidator.isBlankOrNull(value2)){
			if(!value2.equals(value)){
				errors.add(field.getKey(),
						Resources.getActionMessage(validator, request, va, field));
				return false;
			}
		}

		return true;
	}

	protected static boolean isString(Object o) {
		return (o == null) ? true : String.class.isInstance(o);
	}

}
