package net.bobstudio.dms.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.bobstudio.dms.model.Device;
import net.bobstudio.dms.service.DeviceManager;
import net.bobstudio.dms.service.DevicedataManager;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.springside.core.commons.StrutsEntityAction;
import org.springside.core.commons.StrutsAction;

/**
 * 设备管理Controller. 
 * 
 * 
 * @author Bob
 * @see StrutsEntityAction
 * @see StrutsAction
 */
public class DeviceAction extends StrutsEntityAction<Device> {
	private DeviceManager deviceManager;

	public void setDeviceManager(DeviceManager deviceManager) {
		this.deviceManager = deviceManager;
	}

	private DevicedataManager devicedataManager;

	public void setDevicedataManager(DevicedataManager devicedataManager) {
		this.devicedataManager = devicedataManager;
	}

	@Override
	protected DeviceManager getManager() {
		return deviceManager;
	}

	public ActionForward topo(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) {
		list(mapping,form,request,response);
		request.setAttribute("intervalTime", devicedataManager.getIntervalTime()*1000);
		
		//devicedataManager.save(new Devicedata()); //可调用这个manager进行入库操作
		
		return mapping.findForward("topo");
	}
}
