package net.bobstudio.dms.service;

import net.bobstudio.dms.model.Device;

import org.springside.core.commons.HibernateEntityDao;
import org.springside.core.commons.HibernateGenericDao;

/**
 * 设备管理业务类.
 * <p/>
 *
 * @author Bob
 * @see  HibernateEntityDao
 * @see HibernateGenericDao
 * @see DeviceManagerFullVersion
 */
public class DeviceManager extends HibernateEntityDao<Device> {
}
