package net.bobstudio.dms.action;

import net.bobstudio.dms.service.UserManager;
import net.bobstudio.utils.ErrorsEntityAction;
import net.bobstudio.utils.Md5Utils;
import static org.acegisecurity.ui.webapp.AuthenticationProcessingFilter.*;

import org.apache.commons.lang.StringUtils;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessages;
import org.springside.bookstore.components.acegi.cache.AcegiCacheManager;
import org.springside.bookstore.components.acegi.domain.User;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 用户管理Controller. 
 * 
 * @author Bob
 */
public class EditPwdAction extends ErrorsEntityAction<User> {
	private UserManager userManager;
	private AcegiCacheManager acegiCacheManager;

	public void setUserManager(UserManager userManager) {
		this.userManager = userManager;
	}

	@Override
	protected UserManager getManager() {
		// TODO Auto-generated method stub
		return userManager;
	}

	public void setAcegiCacheManager(AcegiCacheManager acegiCacheManager) {
		this.acegiCacheManager = acegiCacheManager;
	}

	/**
	 * 显示新增或修改对象的Form.
	 */
	public ActionForward edit(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) {
		
		System.out.println(acegiCacheManager.getUrlResStrings());
		System.out.println(acegiCacheManager.getComponents());
		System.out.println(acegiCacheManager.getFunctions());

		return mapping.findForward("edit");
	}

	/**
	 * 保存对象
	 */
	public ActionForward save(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) {
		if (isCancelled(request))
			return mapping.findForward(SUCCESS);

		// run validation rules on this form
		ActionMessages errors = form.validate(mapping, request);
		if (!errors.isEmpty()) {
			saveErrors(request, errors);
			return mapping.findForward(EDIT);
		}

		String loginid =(String)request.getSession().getAttribute(ACEGI_SECURITY_LAST_USERNAME_KEY);
		User user;
		if (StringUtils.isNotBlank(loginid)) {
			user = userManager.findUniqueBy("loginid", loginid);
			if (user == null) {
				saveError(request, "entity.missing");
				return mapping.findForward(LIST);
			}
			
			String oldpwd=Md5Utils.MD5(request.getParameter("oldpwd"));
			
			if(!oldpwd.equals(user.getPasswd())) {
				saveError(request, "errors.oldpwd");
				return mapping.findForward(EDIT);
			}
			
			// 将lazyform内容绑定到object
			initEntity(form, request, user);
			
			userManager.save(user);
			saveMessage(request, "entity.editpwd");
		} 
		else {
			saveError(request, "entity.missing");
		}

		return mapping.findForward(SUCCESS);
	}

	/**
	 * 未定义method时的默认方法
	 */
	@Override
	public ActionForward unspecified(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) {
		return mapping.findForward("edit");
	}

	/**
	 * 保存Form表单时，初始化Entity对象的属性.
	 */
	protected void initEntity(ActionForm form, HttpServletRequest request,
			User object) {
		bindObject(form, object);
		onInitEntity(form, request, object);
	}

	/**
	 * 保存Form表单时的回调函数.为业务对象添加更多属性，在子类重载.
	 */
	protected void onInitEntity(ActionForm form, HttpServletRequest request,
			User object) {
		System.out.println(object.getId() + "," + object.getLoginid()
				+ ",==========," + object.getPasswd());
		object.setPasswd(Md5Utils.MD5(object.getPasswd()));
		System.out.println(object.getId() + "," + object.getLoginid()
				+ ",==========," + object.getPasswd());
	}

}
