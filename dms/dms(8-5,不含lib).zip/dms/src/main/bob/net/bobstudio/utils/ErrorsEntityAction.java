package net.bobstudio.utils;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;
import org.springside.core.commons.IEntityDao;
import org.springside.core.commons.StrutsEntityAction;

/**
 * @author Mr. Zhang
 *
 */
public abstract class ErrorsEntityAction<T> extends StrutsEntityAction<T> {
    /**
     * 保存单条信息到Error的简化函数.
     */
    @Override
	protected void saveError(HttpServletRequest request, String key, String... values) {
    	String name =getName(key);
    	
        ActionMessages errors = new ActionMessages();
        errors.add(name, new ActionMessage(key, values));
        saveErrors(request.getSession(), errors);
    }
    
    private String getName(String key) {
    	if(key == null) {
    		return "ANONYMOUS_FIELD";
    	}
    	
    	int index = key.indexOf(".");
    	return (index == -1) ? key : key.substring(key.indexOf(".")+1);
    	
    }
    
    
    @SuppressWarnings("rawtypes")
	public static void main(String [] args){
    	ErrorsEntityAction errors= new ErrorsEntityAction(){

			@Override
			protected IEntityDao getManager() {
				// TODO Auto-generated method stub
				return null;
			}};
    	
    	System.out.println(errors.getName(null));
    	System.out.println(errors.getName(""));
    	System.out.println(errors.getName("nameao"));
    	System.out.println(errors.getName("nameao."));
    	System.out.println(errors.getName("key.name"));
    }

}
