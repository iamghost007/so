package net.bobstudio.dms.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.bobstudio.dms.model.Devicedata;
import net.bobstudio.dms.model.Device;
import net.bobstudio.dms.service.DevicedataManager;
import net.bobstudio.utils.ExtremeTablePage;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.validator.LazyValidatorForm;
import org.extremecomponents.table.limit.Limit;
import org.springside.core.commons.StrutsEntityAction;
import org.springside.core.commons.StrutsAction;
import org.springside.core.commons.support.Page;

import com.dms.alarm.DeviceInfoCenter;

/**
 * 
 * 
 * @author Bob
 * @see StrutsEntityAction
 * @see StrutsAction
 * @see DevicedataActionFullVersion
 */
public class DevicedataAction extends StrutsEntityAction<Devicedata> {
	private DevicedataManager devicedataManager;

	public void setDevicedataManager(DevicedataManager devicedataManager) {
		this.devicedataManager = devicedataManager;
		// System.out.println("DevicedataAction::This is init Manager::devicedataManager:"
		// + devicedataManager);
	}

	/**
	 * 列出所有对象
	 */
	public ActionForward list(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) {
		// 先尝试从request中获取，获取不到再从session中获取DeviceID
		String deviceId = request.getParameter("deviceId");
		if (null == deviceId) {
			HttpSession session = request.getSession(true);
			deviceId = (String) session.getAttribute("deviceId");
			session.removeAttribute("deviceId");
		}

		// ExtremeTable分页
		Limit limit = ExtremeTablePage.getLimit(request, devicedataManager.getPageSize()); // 获取得所需的Limit对象
		Page page = devicedataManager.getNewDevicedatas(limit.getPage(), limit.getCurrentRowsDisplayed(),
				stringIdToInteger(deviceId));

		// 返回ExtremeTable分页结果
		request.setAttribute("pageSize", page.getPageSize());
		request.setAttribute("devicedatas", page.getResult());
		request.setAttribute("totalRows", (int) page.getTotalCount());

		// if (null == deviceId) {
		// // 列出全部清单
		// request.setAttribute("devicedatas", devicedataManager.getAll());
		// } else {
		// // 列出单一工程的清单
		// request.setAttribute("devicedatas",
		// devicedataManager.findDevicedatasByDevice(deviceId));
		// }
		if ("adding".equals(request.getParameter("status"))) {
			request.setAttribute("add.status", true);
		}
		return mapping.findForward(LIST);
	}

	/**
	 * 新增Form.
	 */
	public ActionForward add(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) {
		Devicedata devicedata = null;
		initForm(form, request, devicedata);
		refrenceData(request);
		return mapping.findForward("add");
	}

	public ActionForward lastone(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) {
		return mapping.findForward(doGetLastone(form, request, "lastone"));
	}

	@Override
	public ActionForward view(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) {
		// response.setContentType("text/html");
		// response.setCharacterEncoding("utf-8");
		// PrintWriter out = null;
		// try {
		// out = response.getWriter();
		// // Devicedata data =
		// (Devicedata)request.getAttribute(getEntityName());
		// // System.out.println(data.getMemo()+"===============");
		// // System.out.println(data.getCreateDate()+"================");
		// out.println("2015-05-17 22:13:25");
		// out.println("设备正常乎");
		// } catch (Exception e) {
		// e.printStackTrace();
		// }
		// finally{
		// if(out != null){
		// out.close();
		// }
		// }

		return mapping.findForward(doGetLastone(form, request, VIEW));
	}

	/**
	 * 保存对象的Action函数.
	 */
	public ActionForward save(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) {
		ActionForward forward = super.save(mapping, form, request, response);
		if ("adding".equals(request.getParameter("status"))) {
			return mapping.findForward("addList");
		}
		return forward;
	}

	/**
	 * 删除对象的Action函数.
	 */
	public ActionForward delete(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) {
		String deviceId = request.getParameter("deviceId");
		ActionForward forward = super.delete(mapping, form, request, response);

		// 将request中的值存入session
		HttpSession session = request.getSession(true);
		session.setAttribute("deviceId", deviceId);

		if ("adding".equals(request.getParameter("status"))) {
			return mapping.findForward("addList");
		}
		return forward;
	}

	@Override
	protected DevicedataManager getManager() {
		return devicedataManager;
	}

	@Override
	/**
	 * 从List 到 Edit View中放入Device列表
	 * 
	 * @see StrutsEntityAction#edit(ActionMapping, ActionForm,
	 *      HttpServletRequest, HttpServletResponse)
	 * @see StrutsEntityAction#view(ActionMapping, ActionForm,
	 *      HttpServletRequest, HttpServletResponse)
	 */
	protected void refrenceData(HttpServletRequest request) {
		request.setAttribute("devices", devicedataManager.getDevices());
	}

	@Override
	/**
	 * 显示Form表单时的回调函数，在Form中放入内嵌对象Device的id
	 * 
	 * @see StrutsEntityAction#initForm(ActionForm, HttpServletRequest, T)
	 */
	protected void onInitForm(ActionForm form, HttpServletRequest request, Devicedata devicedata) {
		LazyValidatorForm devicedataForm = (LazyValidatorForm) form;
		if (devicedata != null) {
			// 当进行edit编辑时
			Device device = devicedata.getDevice();
			// devicedataForm.set("deviceId", device.getId());
			// request.setAttribute("device.title", device.getTitle());
		} else {
			// HttpSession session = request.getSession(true);
			// devicedataForm.set("deviceId",
			// (String)session.getAttribute("deviceId"));
		}
	}

	@Override
	/**
	 * 保存Form表单时的回调函数，从request中取出deviceId,并在数据库中查找Device对象设置到devicedata对象中。
	 * 
	 * @see StrutsEntityAction#initEntity(ActionForm, HttpServletRequest, T)
	 */
	protected void onInitEntity(ActionForm form, HttpServletRequest request, Devicedata devicedata) {
		// 将页面选择的工程ID放入Devicedata Bean中
		String deviceId = request.getParameter("deviceId");
		devicedata.setDevice(devicedataManager.getDevice(new Integer(deviceId)));
	}

	protected String doGetLastone(ActionForm form, HttpServletRequest request, String forward) {
		Integer deviceId = stringIdToInteger(request.getParameter("deviceId"));

		Devicedata object = getManager().getLastOneByDeviceId(deviceId);
		if (object == null) {
			saveError(request, "entity.missing");
			return LIST;
		}

		request.setAttribute("intervalTime", devicedataManager.getIntervalTime());
		object.getDevice().setImg(DeviceInfoCenter.getImageById(deviceId));
		request.setAttribute(getEntityName(), object);

		return forward;

	}

	private Integer stringIdToInteger(String sid) {
		Integer iid = null;
		try {
			iid = Integer.valueOf(sid);
		} catch (NumberFormatException e) {
			// do nothing;
		}

		return iid;
	}

}
