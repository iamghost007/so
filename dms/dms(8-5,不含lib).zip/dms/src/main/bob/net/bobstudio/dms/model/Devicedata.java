package net.bobstudio.dms.model;

import java.util.Date;

public class Devicedata {
    private Integer id;
    
    private Device device;

    private String memo;

    private Date createDate = null;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Device getDevice() {
        return device;
    }

    public void setDevice(Device device) {
        this.device = device;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }

    public Date getCreateDate() {
        return createDate == null ? new Date() : createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

}
