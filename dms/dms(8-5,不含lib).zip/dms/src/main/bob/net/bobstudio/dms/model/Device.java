package net.bobstudio.dms.model;

import java.util.Set;

public class Device {
    private Integer id;

    private Set<Devicedata> data;

    private String name; // 标题
    
    private String img;

    private String specs; // 备注

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Set<Devicedata> getData() {
        return data;
    }

    public void setData(Set<Devicedata> data) {
        this.data = data;
    }

    public String getSpecs() {
        return specs;
    }

    public void setSpecs(String specs) {
        this.specs = specs;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

	public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img;
	}

}
