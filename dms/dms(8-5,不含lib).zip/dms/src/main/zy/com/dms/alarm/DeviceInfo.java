package com.dms.alarm;

public class DeviceInfo implements IMessage {
	private static int SN_INDEX = 1;
	private static int DEVICE_ID_INDEX = 2;
	private static int DATA = 3;
	public int sn;
	public int deviceId;
	public String  data;
	
	public boolean parse(String msg) {
		String array[] = msg.split(",");
		if (array.length != 4) {
			return false;
		} else {
			try {
				sn = Integer.parseInt(array[SN_INDEX]);
				deviceId = Integer.parseInt(array[DEVICE_ID_INDEX]);
				data = array[DATA];
			} catch (Exception e) {
				e.printStackTrace();
			}

			return true;
		}
	}

	public boolean isSelf(String msg) {
		return msg.startsWith("$DATA");
	}

	public void handle() {
		DeviceStatusCenter.putDeviceInfo(deviceId, data);
	}
	
	@Override
	public String toString() {
		return "Message [sn=" + sn + ", deviceId=" + deviceId + ", data="
				+ data + "]";
	}

}
