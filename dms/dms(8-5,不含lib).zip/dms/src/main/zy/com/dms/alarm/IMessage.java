package com.dms.alarm;

public interface IMessage {
	boolean parse(String msg);
	
	boolean isSelf(String msg);
	
	void handle();
}
