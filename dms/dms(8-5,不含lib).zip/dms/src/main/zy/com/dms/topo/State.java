package com.dms.topo;

import java.util.ArrayList;
import java.util.List;

public class State {
	public String color = TopoConstants.NORMAL_COLOR;
	public List<String> alarms = new ArrayList<String>();
	public List<String> alarmTimes = new ArrayList<String>();
}
