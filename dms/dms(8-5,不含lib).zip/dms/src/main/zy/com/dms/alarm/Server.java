package com.dms.alarm;

import java.net.*;
import java.io.*;

public class Server {
	private ServerSocket ss;
	private Socket socket;
	private PrintWriter out;

	private static final int DEVICE_NUM = 10;

	public Server() {
		try {
			ss = new ServerSocket(Client.PORT);
			try {
				while (true) {
					socket = ss.accept();
					while (true) {
						returnAlarm();
						returnDeviceInfo();
						sleep(5000);
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void returnDeviceInfo() throws IOException {
		out = new PrintWriter(socket.getOutputStream(), true);
		int i = 0;
		// $DATA,SN,ID,DATA\r\n
		int num = (int) ((Math.random()) * 100) / 10;
		for (int k = 0; k < DEVICE_NUM; ++k) {
			out.print("$DATA");
			out.print(",");
			out.print(i);
			out.print(",");
			out.print(k);
			
			// out.print(1);
			out.print(",");
			out.print("test data");
			byte b=(byte)0;
			char c=(char)b;
			out.print(c);
			out.print("23445");
			out.print("\r\n");
			out.flush();
		}
		++i;
	}

	private void returnAlarm() throws IOException {
		out = new PrintWriter(socket.getOutputStream(), true);
		int i = 0;

		int num = (int) ((Math.random()) * 100) / 10;
		for (int k = 0; k < DEVICE_NUM; ++k) {
			out.print("$STATUS");
			out.print(",");
			out.print(i);
			out.print(",");
			out.print(k);
			// out.print(1);
			out.print(",");
			out.print(k == num ? 1 : 0);
			// out.print(k);
			out.print(",");
			out.print(k == num ? 1 : 0);
			// out.print(k);
			out.print("\r\n");
			out.flush();
		}
		++i;
	}

	@SuppressWarnings("static-access")
	private void sleep(long millis) {

		try {
			Thread.currentThread().sleep(millis);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		System.out.println("Server start!!!!!");
		new Server();
	}
}
