package com.dms.alarm;

import java.io.*;
import java.net.*;

public class Client {
	public static int PORT = 8000;

	public static final int CMD_RESTART = 2;
	public static final int CMD_QUERY = 1;
	private static final long WAIT_TIME = 5000;
	private static final int BEGIN_ID = 0;
	private static final int END_ID = 9;

	private static Socket socket;
	private static InputStream in;
	private static BufferedWriter out;
	private static int sn = 0;

	public Client() {
		startClient();

		queryDeviceInfo();
	}

	private void startClient() {
		new Thread(new Runnable() {
			public void run() {
				while (true) {
					try {
						readInfo();
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		}).start();
	}

	private void queryDeviceInfo() {
		new Thread(new Runnable() {
			public void run() {
				sleep(WAIT_TIME / 2);
				while (true) {
					for (int i = BEGIN_ID; i <= END_ID; ++i) {
						sendDataCmd(i);
					}
					sleep(WAIT_TIME);
				}
			}

		}).start();
	}

	private void sleep(long time) {
		try {
			Thread.sleep(time);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void readInfo() {
		try {
			socket = new Socket(DeviceInfoCenter.getServerIP(),
					DeviceInfoCenter.getServerPort());
			in = socket.getInputStream();
			out = new BufferedWriter(new OutputStreamWriter(
					socket.getOutputStream()));
			BufferParser parser = new BufferParser();
			byte[] bytes = new byte[500];
			while (true) {
				int length = in.read(bytes);
				if (length == -1) {
					return;
				}
				
				String msg = parser.getMsg(bytes, length);

				if (msg.length() == 0) {
					continue;
				}

				System.out.println("msg:" + msg);
				Status status = new Status();
				if (status.isSelf(msg)) {
					status.parse(msg);
					status.handle();
					continue;
				}

				DeviceInfo info = new DeviceInfo();
				if (info.isSelf(msg)) {
					info.parse(msg);
					info.handle();
					continue;
				}

			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (in != null) {
				try {
					in.close();
					in = null;
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

			if (out != null) {
				try {
					out.close();
					out = null;
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

			if (socket != null) {
				try {
					socket.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public static boolean sendRestartCmd(int deviceId) {
		return sendControlCmd(deviceId, CMD_RESTART);
	}

	private static boolean sendControlCmd(int deviceId, int cmd) {
		if (out != null) {
			try {
				out.write(getCmdStr(deviceId, cmd));
				out.flush();
				return true;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return false;
	}

	private static String getCmdStr(int id, int cmd) {
		// $CTRL,SN,ID,CMD \r\n
		StringBuffer buf = new StringBuffer();
		buf.append("$CTRL,");
		buf.append(getSN() + ",");
		buf.append(id + ",");
		buf.append(cmd + "\r\n");
		return buf.toString();
	}

	private static int getSN() {
		int result = sn;
		sn = sn + 1;
		if (sn > 65535) {
			sn = 0;
		}
		return result;
	}

	public static boolean sendDataCmd(int id) {
		return sendControlCmd(id, CMD_QUERY);
	}

	public static void main(String[] args) {
		new Client();
	}
}
