package com.dms.alarm;

import java.util.HashMap;
import net.bobstudio.dms.model.Devicedata;
import net.bobstudio.dms.service.DevicedataManager;
import net.bobstudio.utils.ApplicationContextHelper;

import com.dms.topo.TopoState;

public class DeviceStatusCenter {
	private static HashMap<Integer, Status> statusCenter = new HashMap<Integer, Status>();

	private static HashMap<Integer, String> deviceInfCenter = new HashMap<Integer, String>();

	public static synchronized void putStatus(Status currentStatus) {
		Status oldStatus = statusCenter.get(currentStatus.deviceId);

		if (oldStatus == null) {
			statusCenter.put(currentStatus.deviceId, currentStatus);

			saveStatus(currentStatus);
			TopoState.update(currentStatus.deviceId);
		} else {
			if (oldStatus.errorCode != currentStatus.errorCode) {
				statusCenter.put(currentStatus.deviceId, currentStatus);

				saveStatus(currentStatus);
				TopoState.update(currentStatus.deviceId);
			}
		}
	}

	private static void saveStatus(Status status) {
		DevicedataManager devicedataManager = (DevicedataManager) ApplicationContextHelper
				.getBean("devicedataManager");
		Devicedata data = new Devicedata();
		data.setMemo(DeviceInfoCenter.getDevice(status.deviceId).getErrorTip(
				status.errorCode));
		net.bobstudio.dms.model.Device device = new net.bobstudio.dms.model.Device();
		device.setId(status.deviceId);
		data.setDevice(device);
		devicedataManager.save(data); // 可调用这个manager进行入库操作
	}

	public static synchronized Status getStatus(int deviceId) {
		Status s = statusCenter.get(deviceId);
		return s;
	}

	public static synchronized Status getStatus(String strId) {
		return getStatus(DeviceInfoCenter.getIntId(strId));
	}

	public synchronized static String getDeviceInfo(int deviceId) {
		return deviceInfCenter.get(deviceId);
	}

	public synchronized static void putDeviceInfo(int deviceId, String data) {
		deviceInfCenter.put(deviceId, data);
	}
}
