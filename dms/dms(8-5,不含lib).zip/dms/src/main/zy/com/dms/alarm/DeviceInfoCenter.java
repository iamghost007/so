package com.dms.alarm;

import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import com.dms.topo.TopoConstants;

public class DeviceInfoCenter {
	public static HashMap<Integer, Device> info = null;

	private static String FILE_NAME = "deviceConf.xml";

	private static String serverIP = null;
	private static int serverPort = 0;

	private static HashMap<String, Integer> strToIntMap = new HashMap<String, Integer>();

	private static HashMap<Integer, String> intToStrMap = new HashMap<Integer, String>();
	static {
		init(TopoConstants.serialPortRS232Device0, 0);
		init(TopoConstants.serialPortRS232Device1, 1);
		init(TopoConstants.serialPortRS232Device2, 2);
		init(TopoConstants.serialPortRS232Device3, 3);
		init(TopoConstants.canPortDevice0, 4);
		init(TopoConstants.canPortDevice1, 5);
		init(TopoConstants.serialPortRS485Device0, 6);
		init(TopoConstants.serialPortRS485Device1, 7);
		init(TopoConstants.ethPortDevice0, 8);
		init(TopoConstants.monitor, 9);
		init(TopoConstants.serialPortRS232, 10);
		init(TopoConstants.serialPortRS485, 11);
		init(TopoConstants.canPort, 12);
		init(TopoConstants.ethPort, 13);
	}

	public static int getIntId(String strId) {
		return strToIntMap.get(strId);
	}

	public static String getImageById(int deviceId) {
		return "../images/topo/" + intToStrMap.get(deviceId) + ".png";
	}

	private static void init(String s, int i) {
		strToIntMap.put(s, i);
		intToStrMap.put(i, s);
	}

	public static void main(String[] args) {
		Device d = getDevice(1);
		System.out.println(d.id);
	}

	private synchronized static void parse() {
		SAXReader reader = new SAXReader();
		Document document;
		info = new HashMap<Integer, Device>();
		try {
			String path = Thread.currentThread().getContextClassLoader()
					.getResource("/").getPath();
			path = path.substring(0, path.lastIndexOf("classes"));
			
			document = reader.read(new File(path + FILE_NAME));
			
			Element root = document.getRootElement();
			
			handleSeverNode(root);
			
			handleDeviceNode(root);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private static void handleSeverNode(Element root) {
		List list = root.elements("server");
		for (Iterator i = list.iterator(); i.hasNext();) {
			Element serverItem = (Element) i.next();
			serverPort = toInt(serverItem.attributeValue("port"));
			serverIP = serverItem.attributeValue("ip");
		}
	}

	private static void handleDeviceNode(Element root) {
		List list = root.elements("device");
		for (Iterator i = list.iterator(); i.hasNext();) {
			Element deviceItem = (Element) i.next();
			Device device = new Device();
			device.id = toInt(deviceItem.attributeValue("id"));
			device.img = deviceItem.attributeValue("img");
			List errorList = deviceItem.elements("error");
			for (Iterator k = errorList.iterator(); k.hasNext();) {
				Element errorItem = (Element) k.next();
				device.setError(toInt(errorItem.attributeValue("code")),
						errorItem.attributeValue("tip"));
			}
			info.put(device.id, device);
		}
	}

	private static int toInt(String s) {
		return Integer.parseInt(s);
	}

	public synchronized static Device getDevice(int id) {
		if (info == null) {
			parse();
		}

		return info.get(id);

	}

	public synchronized static Device getDevice(String strId) {
		return getDevice(getIntId(strId));
	}

	public synchronized static String getStrId(int id) {
		return intToStrMap.get(id);
	}

	public synchronized static String getServerIP() {
		if (serverIP == null) {
			parse();
		}
		return serverIP;
	}

	public synchronized static int getServerPort() {
		if (serverPort == 0) {
			parse();
		}
		return serverPort;
	}
}
