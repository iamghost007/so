package com.dms.topo;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import com.dms.alarm.DeviceInfoCenter;
import com.dms.alarm.DeviceStatusCenter;
import com.dms.alarm.Status;

public class TopoState {
	private static Map<String, State> STATE = new HashMap<String, State>();

	static {
		STATE.put(TopoConstants.serialPortRS232Device0, new State());
		STATE.put(TopoConstants.serialPortRS232Device1, new State());
		STATE.put(TopoConstants.serialPortRS232Device2, new State());
		STATE.put(TopoConstants.serialPortRS232Device3, new State());
		STATE.put(TopoConstants.serialPortRS232, new State());

		STATE.put(TopoConstants.serialPortRS485, new State());
		STATE.put(TopoConstants.serialPortRS485Device0, new State());
		STATE.put(TopoConstants.serialPortRS485Device1, new State());

		STATE.put(TopoConstants.canPort, new State());
		STATE.put(TopoConstants.canPortDevice0, new State());
		STATE.put(TopoConstants.canPortDevice1, new State());

		STATE.put(TopoConstants.ethPort, new State());
		STATE.put(TopoConstants.ethPortDevice0, new State());

		STATE.put(TopoConstants.monitor, new State());
	}

	public synchronized static Map<String, State> getStateMap() {
		return STATE;
	}

	public synchronized static void update(int intId) {
			String strId = DeviceInfoCenter.getStrId(intId);
			Status status = DeviceStatusCenter.getStatus(intId);
			State state = new State();
			if (status != null) {
				if (status.errorCode != 0) {
					state.color = TopoConstants.ALARM_COLOR;
					String errorTip = DeviceInfoCenter.getDevice(intId).getErrorTip(status.errorCode);
					state.alarms.add(errorTip != null ? errorTip : "未知错误");
					state.alarmTimes.add(getDate());
				}
			}
			TopoState.getStateMap().put(strId, state);
	}

	private static String getDate() {
		Date d = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return formatter.format(d);
	}

	public synchronized static String getColor(String id) {
		return getStateMap().get(id).color;
	}

}
