package com.dms.topo;

public interface TopoConstants {
	String TOPO_STATE_RESPONSE_URL = "servlet/TopoStateResponse";
	String DEVICE_CMD_RESPONSE_URL = "servlet/DeviceCmdResponse";

	String NORMAL_COLOR = "#00FF00";
	String ALARM_COLOR = "#FF0000";

	String serialPortRS232Device0 = "serialPortRS232Device0";
	String serialPortRS232Device1 = "serialPortRS232Device1";
	String serialPortRS232Device2 = "serialPortRS232Device2";
	String serialPortRS232Device3 = "serialPortRS232Device3";
	String serialPortRS232 = "serialPortRS232";

	String serialPortRS485 = "serialPortRS485";
	String serialPortRS485Device0 = "serialPortRS485Device0";
	String serialPortRS485Device1 = "serialPortRS485Device1";
	
	String ethPort = "ethPort";
	String ethPortDevice0 = "ethPortDevice0";
	
	String canPort = "canPort";
	String canPortDevice0 = "canPortDevice0";
	String canPortDevice1 = "canPortDevice1";
	
	String monitor = "monitor";
}
