package com.dms.alarm;

public class Status implements IMessage{
	private static int SN_INDEX = 1;
	private static int DEVICE_ID_INDEX = 2;
	private static int STATUS_INDEX = 3;
	private static int ERROR_CODE_INDEX = 4;
	public int sn;
	public int deviceId;
	public int status;
	public int errorCode;

	public Status() {
	}

	public boolean parse(String msg) {
		String array[] = msg.split(",");
		if (array.length != 5) {
			return false;
		} else {
			try {
				sn = Integer.parseInt(array[SN_INDEX]);
				deviceId = Integer.parseInt(array[DEVICE_ID_INDEX]);
				status = Integer.parseInt(array[STATUS_INDEX]);
				errorCode = Integer.parseInt(array[ERROR_CODE_INDEX]);
			} catch (Exception e) {
				e.printStackTrace();
			}

			return true;
		}
	}

	@Override
	public String toString() {
		return "Message [sn=" + sn + ", deviceId=" + deviceId + ", status="
				+ status + ", errorCode=" + errorCode + "]";
	}

	public boolean isSelf(String msg) {
		return msg.startsWith("$STATUS");
	}

	public void handle() {
		DeviceStatusCenter.putStatus(this);
	}
	
	

}
