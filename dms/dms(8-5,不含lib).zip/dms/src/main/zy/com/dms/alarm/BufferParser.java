package com.dms.alarm;

import java.util.LinkedList;

public class BufferParser {
	LinkedList<Byte> buf = new LinkedList<Byte>();

	public String getMsg(byte[] bytes, int length) {
		for (int i = 0; i < length; ++i) {
			buf.add(bytes[i]);
		}

		StringBuffer result = new StringBuffer();

		for (int i = 0; i < buf.size(); ++i) {
			Byte current = buf.get(i);
			if (current.byteValue() == '\r') {
				if ((i + 1) < buf.size()) {
					Byte next = buf.get(i + 1);
					if (next.byteValue() == '\n') {
						delete(i + 1);
						return result.toString();
					}
				}
			}
			if (current == 0) {
				result.append("\r\n");
			} else {
				char c = (char)current.byteValue();
				result.append(c);
			}
		}

		return "";

	}

	private void delete(int endIndex) {
		for (int i = endIndex; i >= 0; --i) {
			buf.remove(i);
		}
	}
}
