package com.dms.alarm;

import java.util.HashMap;

public class Device {
	public int id;
	public String img;
	private HashMap<Integer, String> errors = new HashMap<Integer, String>();

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}

	public void setError(int errorCode, String tip) {
		errors.put(errorCode, tip);
	}

	public String getErrorTip(int errorCode) {
		if (errorCode == 0) {
			return "设备正常";
		}

		String errorTip = errors.get(errorCode);
		if (errorTip == null) {
			return "未知错误，错误码=" + errorCode;
		} else {
			return errorTip;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Device other = (Device) obj;
		if (id != other.id)
			return false;
		return true;
	}

}
