package com.dms.topo;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dms.alarm.Client;
import com.dms.alarm.DeviceStatusCenter;

public class TopoStateResponse extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static boolean first = true;

	/**
	 * Constructor of the object.
	 */
	public TopoStateResponse() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 * 
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request
	 *            the request send by the client to the server
	 * @param response
	 *            the response send by the server to the client
	 * @throws ServletException
	 *             if an error occurred
	 * @throws IOException
	 *             if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		if (isDeviceCmdRequest(request)) {
			handleDeviceCmd(request, response);
		} else {
			handleTopoState(response);
		}

		// makeSimulationData();
	}

	private void handleDeviceCmd(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		int deviceId = Integer.parseInt(request.getParameter("deviceId"));
		int cmd = Integer.parseInt(request.getParameter("cmd"));

		response.setContentType("text/html");
		response.setCharacterEncoding("utf-8");
		PrintWriter out = response.getWriter();
		if (cmd == Client.CMD_QUERY) {
			handleDeviceQueryInfo(deviceId, out);
		} else if (cmd == Client.CMD_RESTART) {
			handDeviceRestart(deviceId, out);
		}
		out.close();
		System.out.println("DeviceCmdResponse：deviceId=" + deviceId + " , "
				+ "cmd=" + cmd);
	}

	private void handleDeviceQueryInfo(int deviceId, PrintWriter out) {
		String info=DeviceStatusCenter.getDeviceInfo(deviceId);
		out.println(info!=null?info:"");
	}

	private void handDeviceRestart(int deviceId, PrintWriter out) {
		boolean result = Client.sendRestartCmd(deviceId);
		//out.println("<html><head><meta http-equiv='Content-Type' content='text/html;charset=UTF-8'></head><body>");
		if (result) {
			out.println("设备重启命令发送成功！");
		} else {
			out.println("设备重启命令发送失败！");
		}
		//out.println("</body></html>");
	}

	private void handleTopoState(HttpServletResponse response)
			throws IOException {
		response.setContentType("text/html");
		response.setCharacterEncoding("utf-8");
		PrintWriter out = response.getWriter();
		StringBuffer buf = new StringBuffer();
		Set<Map.Entry<String, State>> set = TopoState.getStateMap().entrySet();
		for (Map.Entry<String, State> entry : set) {
			buf.append(entry.getKey()).append("=")
					.append(entry.getValue().color).append(";");
		}

		out.print(buf.toString());

		out.close();
	}

	private boolean isDeviceCmdRequest(HttpServletRequest request) {
		String cmd = request.getParameter("cmd");
		return cmd != null;
	}

	private void makeSimulationData() {

		if (!first) {
			return;
		}

		new Thread(new Runnable() {

			public void run() {
				first = false;
				String key = "";
				while (true) {
					sleep(1000 * 20);
					if (!key.equals("")) {
						TopoState.getStateMap().put(key, new State());
					}

					int num = (int) ((Math.random()) * 100) / 10;
					switch (num) {
					case 0:
						key = TopoConstants.canPortDevice0;
						break;
					case 1:
						key = TopoConstants.canPortDevice1;
						break;
					case 2:
						key = TopoConstants.serialPortRS232Device0;
						break;
					case 3:
						key = TopoConstants.serialPortRS232Device1;
						break;
					case 4:
						key = TopoConstants.serialPortRS232Device2;
						break;
					case 5:
						key = TopoConstants.serialPortRS232Device3;
						break;
					case 6:
						key = TopoConstants.serialPortRS485Device0;
						break;
					case 7:
						key = TopoConstants.serialPortRS485Device1;
						break;
					case 8:
						key = TopoConstants.ethPortDevice0;
						break;
					default:
						key = TopoConstants.monitor;
						break;
					}

					TopoState.getStateMap().put(key, createSimulation());
				}

			}

			@SuppressWarnings("static-access")
			private void sleep(long m) {
				try {
					Thread.currentThread().sleep(m);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}).start();
		;
	}

	String getRandmonColor() {
		int num = (int) ((Math.random()) * 100);
		return num == 0 ? TopoConstants.ALARM_COLOR
				: TopoConstants.NORMAL_COLOR;
	}

	private State createSimulation() {
		State state = new State();
		state.color = TopoConstants.ALARM_COLOR;
		state.alarms.add("温度过高");
		state.alarmTimes.add(getDate());

		state.alarms.add("CPU使用率超过90%");
		state.alarmTimes.add(getDate());

		return state;
	}

	public static String getDate() {
		Date d = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return formatter.format(d);
	}

	/**
	 * The doPost method of the servlet. <br>
	 * 
	 * This method is called when a form has its tag value method equals to
	 * post.
	 * 
	 * @param request
	 *            the request send by the client to the server
	 * @param response
	 *            the response send by the server to the client
	 * @throws ServletException
	 *             if an error occurred
	 * @throws IOException
	 *             if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	/**
	 * Initialization of the servlet. <br>
	 * 
	 * @throws ServletException
	 *             if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
		// new Client();
		// DeviceInfoCenter.main(null);
		new Client();
	}

}
