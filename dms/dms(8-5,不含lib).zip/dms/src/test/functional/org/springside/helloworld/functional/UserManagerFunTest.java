package org.springside.helloworld.functional;

import org.springside.core.test.FunctionalTestCase;

/**
 * 用户管理界面的集成测试.
 * <p/>
 * 对函数与变量名已作泛化,可以快速复制新的领域对象CRUD管理界面.
 *
 * @author calvin
 */
public class UserManagerFunTest extends FunctionalTestCase {

    @Override
    public void setUp() {
        super.setUp();
        user.open("/helloworld");
        user.waitForPageToLoad("3000");
    }

    public void testEntityList() {
        String[] entities = new String[]{"calvin", "cac"};
        for (String entityName : entities)
            assertTrue(entityName + " shoule be shown on page", user.isTextPresent(entityName));
    }

    public void testEntityAdd() {
        String entityName = "TestEntity";
        user.click("addbutton");
        user.waitForPageToLoad("3000");
        user.type("name", entityName);
        user.click("save");
        user.waitForPageToLoad("3000");
        assertTrue(entityName + " shoule be shown on page", user.isTextPresent(entityName));
    }

    public void testEntityEdit() {
        String newName = "NewEntityName";
        user.click("//a[contains(@href, 'user.htm?method=edit&id=0')]");
        user.waitForPageToLoad("3000");
        user.type("name", newName);
        user.click("save");
        user.waitForPageToLoad("3000");
        assertTrue(newName + " should be shown on page", user.isTextPresent(newName));
    }

    public void testEntityDelete() {
        String entityName = "calvin";
        user.click("//a[contains(@href, 'user.htm?method=delete&id=0')]");
        user.waitForPageToLoad("3000");
        assertTrue(entityName + " shouldn't be shown on page", !user.isTextPresent(entityName));
    }
}
