CREATE TABLE USER(
ID INTEGER NOT NULL auto_increment,
NAME VARCHAR(80) NOT NULL,
EMAIL VARCHAR(100),
DESCN VARCHAR(255),
CONSTRAINT PK_USER PRIMARY KEY(ID))

INSERT INTO USER VALUES(1,'calvin','calvinxiu@gmail.com','SpringSide Developer')
INSERT INTO USER VALUES(2,'cac','johnsonchen916@gmail.com','SpringSide Developer')
INSERT INTO USER VALUES(3,'sshwsfc','sshwsfc@gamil.com','SpringSide Developer')
